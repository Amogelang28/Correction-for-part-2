import React, { createContext, useContext, useState, ReactNode } from 'react';
import { MenuItem } from './MenuContext';

type SelectedMealsContextType = {
  selectedMeals: MenuItem[];
  toggleMeal: (item: MenuItem) => void;
  clearMeals: () => void;
};

const SelectedMealsContext = createContext<SelectedMealsContextType | undefined>(undefined);

export const SelectedMealsProvider = ({ children }: { children: ReactNode }) => {
  const [selectedMeals, setSelectedMeals] = useState<MenuItem[]>([]);

  const toggleMeal = (item: MenuItem) => {
    setSelectedMeals(prev =>
      prev.find(m => m.id === item.id)
        ? prev.filter(m => m.id !== item.id)
        : [...prev, item]
    );
  };

  const clearMeals = () => setSelectedMeals([]);

  return (
    <SelectedMealsContext.Provider value={{ selectedMeals, toggleMeal, clearMeals }}>
      {children}
    </SelectedMealsContext.Provider>
  );
};

export const useSelectedMeals = () => {
  const context = useContext(SelectedMealsContext);
  if (!context) {
    throw new Error('useSelectedMeals must be used within a SelectedMealsProvider');
  }
  return context;
};