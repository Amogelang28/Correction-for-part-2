import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function Payment({ navigation }: any) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Payment Screen</Text>
      <Text style={styles.info}>[Payment integration here]</Text>
      <Button
        title="Confirm Order"
        color="#000"
        onPress={() => navigation.navigate('OrderConfirmed')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24 },
  title: { color: '#FFF', fontSize: 22, fontFamily: 'ABeeZee', marginBottom: 20 },
  info: { color: 'rgba(0,0,0,0.76)', marginBottom: 20, fontFamily: 'ABeeZee' },
});