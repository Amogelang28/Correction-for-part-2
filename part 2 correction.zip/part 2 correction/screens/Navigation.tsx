import React from 'react';
import { NavigationContainer } from '@react-Navigation/native';
import { createNativeStackNavigator } from '@react-Navigation/native-stack';
import Layout from '../screens/Layout';

export type MenuItem = {
  id: string;
  name: string;
  description: string;
  course: string;
  price: number;
};

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Layout" component={Layout} />
      </Stack.Navigator>
      </NavigationContainer>
   
  );
}