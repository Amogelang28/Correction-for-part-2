import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { MenuItem } from '../App';

export default function SelectedItems({ navigation, route }: any) {
  const { menuItems } = route.params as { menuItems: MenuItem[] };
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const toggle = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const selected = menuItems.filter(i => selectedIds.includes(i.id));

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Select Dishes</Text>
      <FlatList
        data={menuItems}
        keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => toggle(item.id)}>
            <Text style={styles.item}>
              {selectedIds.includes(item.id) ? '✔ ' : ''}{item.name}
            </Text>
          </TouchableOpacity>
        )}
      />
      <Button
        title={'Next (${selected.length}, ${chosen})'}
        color="#000"
        onPress={() => navigation.navigate('Next', { selected })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { color: '#FFF', fontSize: 22, fontFamily: 'ABeeZee', marginBottom: 12 },
  item: { color: 'rgba(0,0,0,0.76)', marginVertical: 4, fontFamily: 'ABeeZee' },
});