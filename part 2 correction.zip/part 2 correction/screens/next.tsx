import React from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import { MenuItem } from '../App';

export default function Next({ navigation, route }: any) {
  const { selected } = route.params as { selected: MenuItem[] };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Review Your Order</Text>
      <FlatList
        data={selected}
        keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <Text style={styles.item}>{item.name} — R{item.price.toFixed(2)}</Text>
        )}
      />
      <Button
        title="Proceed to Payment"
        color="#000"
        onPress={() => navigation.navigate('Payment', { selected })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { color: '#FFF', fontSize: 22, fontFamily: 'ABeeZee' },
  item: { color: 'rgba(0,0,0,0.76)', marginVertical: 4, fontFamily: 'ABeeZee' },
});