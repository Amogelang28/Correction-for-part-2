import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import  MenuItem  from '../App';

export default function Home({ navigation }: any) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu Items</Text>
      <Button
        title="Add Item"
        color="#000"
        onPress={() => navigation.navigate('AddItems', { setMenuItems })}
      />
      <FlatList
        data={menuItems}
        keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <Text style={styles.item}>
            {item.name} ({item.course}) - R{item.price}
          </Text>
        )}
      />
      <Button
        title="Filter"
        color="#000"
        onPress={() => navigation.navigate('Filter', { menuItems })}
      />
      <Button
        title="Select Items"
        color="#000"
        onPress={() => navigation.navigate('SelectedItems', { menuItems })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: {
    color: '#FFF',
    fontSize: 22,
    fontFamily: 'ABeeZee',
    marginBottom: 8,
  },
  item: {
    color: 'rgba(0,0,0,0.76)',
    fontFamily: 'ABeeZee',
  },
});