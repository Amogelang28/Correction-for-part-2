import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import MenuItem from '../App'; 

export default function Filter({ navigation, route }: any) {
  const { menuItems } = route.params as { menuItems: Menuitem[] };
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const courses = Array.from(new Set(menuItems.map(i => i.course)));

  const filtered = selectedCourse
    ? menuItems.filter(i => i.course === selectedCourse)
    : menuItems;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Filter By Course</Text>
      {courses.map(c => (
        <Button
          key={c}
          title={c}
          color={selectedCourse === c ? '#000' : 'rgba(0,0,0,0.4)'}
          onPress={() =>
            setSelectedCourse(prev => (prev === c ? null : c))
          }
        />
      ))}
      <FlatList
        data={filtered}
        keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <Text style={styles.item}>
            {item.name} — R{item.price.toFixed(2)}
          </Text>
        )}
      />
      <Button title="Back" color="#000" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: {
    color: '#FFF', fontSize: 22, fontFamily: 'ABeeZee', marginBottom: 12
  },
  item: {
    color: 'rgba(0,0,0,0.76)', marginVertical: 4, fontFamily: 'ABeeZee'
  },
});