import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function OrderConfirmed({ navigation }: any) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Order Confirmed!</Text>
      <Text style={styles.subtitle}>Thank you for your purchase.</Text>
      <Button
        title="Review Your Order"
        color="#000"
        onPress={() => navigation.navigate('ReviewConfirmation')}
      />
      <Button
        title="Back to Home"
        color="#000"
        onPress={() => navigation.navigate('Home')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24 },
  title: { color: '#FFF', fontSize: 24, fontFamily: 'ABeeZee', marginBottom: 12 },
  subtitle: { color: 'rgba(0,0,0,0.76)', fontFamily: 'ABeeZee', marginBottom: 20 },
});