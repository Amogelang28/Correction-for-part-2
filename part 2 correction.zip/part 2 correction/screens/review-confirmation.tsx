import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function ReviewConfirmation({ navigation }: any) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Review Your Experience</Text>
      <Text style={styles.info}>How was your order?</Text>
      <Button
        title="Write a Review"
        color="#000"
        onPress={() => { /* navigate to review form */ }}
      />
      <Button
        title="Back to Home"
        color="#000"
        onPress={() => navigation.navigate('Home')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24 },
  title: { color: '#FFF', fontSize: 22, fontFamily: 'ABeeZee', marginBottom: 12 },
  info: { color: 'rgba(0,0,0,0.76)', fontFamily: 'ABeeZee', marginBottom: 20 },
});