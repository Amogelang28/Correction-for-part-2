import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

const courses = ['Starters', 'Mains', 'Desserts'];

export default function AddItems({ navigation, route }: any) {
  const { setMenuItems } = route.params;
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState(courses[0]);

  const save = () => {
    setMenuItems((prev: any) => [
      ...prev,
      {
        id: Date.now().toString(),
        name,
        description: desc,
        price: parseFloat(price),
        course,
      },
    ]);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Dish Name</Text>
      <TextInput style={styles.input} onChangeText={setName} value={name} />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, { height: 80 }]}
        onChangeText={setDesc}
        value={desc}
        multiline
      />

      <Text style={styles.label}>Price</Text>
      <TextInput
        style={styles.input}
        onChangeText={setPrice}
        value={price}
        keyboardType="numeric"
      />

      <Text style={styles.label}>Course</Text>
      {courses.map(c => (
        <TouchableOpacity key={c} onPress={() => setCourse(c)}>
          <Text
            style={[
              styles.course,
              course === c && { backgroundColor: '#000', color: '#FFF' },
            ]}
          >
            {c}
          </Text>
        </TouchableOpacity>
      ))}

      <Button title="Save" color="#000" onPress={save} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  label: { color: '#FFF', fontFamily: 'ABeeZee', marginTop: 8 },
  input: {
    backgroundColor: '#FFF',
    borderRadius: 4,
    padding: 8,
    marginTop: 4,
  },
  course: {
    color: 'rgba(0,0,0,0.76)',
    padding: 6,
    marginVertical: 4,
    backgroundColor: '#FFF',
    fontFamily: 'ABeeZee',
  },
});