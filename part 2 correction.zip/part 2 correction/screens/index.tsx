import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function Index({ navigation }: any) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        <Text style={styles.italic}>Christoffel</Text>'s Restaurant
      </Text>
      <Button
        title="Go to Home"
        color="#000"
        onPress={() => navigation.navigate('Home')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { color: '#FFF', fontSize: 28, fontFamily: 'ABeeZee' },
  italic: { fontStyle: 'italic', fontFamily: 'ABeeZeeItalic' },
});