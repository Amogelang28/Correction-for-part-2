import React from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';

type Props = { children: React.ReactNode };

export default function Layout({ children }: Props) {
  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#B6BEC9" barStyle="light-content" />
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#B6BEC9' },
});